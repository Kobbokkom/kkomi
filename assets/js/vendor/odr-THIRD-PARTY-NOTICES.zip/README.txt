Third-party notices for the locally built OpenDocument.core 7.7.0 WebAssembly module.
Library versions and Conan recipes are pinned by upstream conan.lock at fae77ff7232cc79eecaebeb9e6839acf568d09c2.
Emscripten 3.1.73 also links the LLVM runtime libraries. The libc++ license here is shared by libc++abi.
Unmodified uchardet 0.0.8 is available under the Mozilla Public License 1.1 from:
https://www.freedesktop.org/software/uchardet/releases/uchardet-0.0.8.tar.xz
Emscripten source: https://github.com/emscripten-core/emscripten/tree/3.1.73
OpenDocument.core source instructions are in odr-SOURCE.txt alongside this archive.
